package matrizdinamica;


public class Matrizdinamica {

    public static void main(String[] args) {
        // TODO code application logic here
        
        Matriz t = new Matriz(3, 3, 3);
        
        t.print();
        System.out.println(t.size());
        //t.print();
    }
    
}
